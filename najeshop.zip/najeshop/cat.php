<?php
include 'dbconnect.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $new_cat_title = $_POST['cat_title'];
    if (!empty($new_cat_title)) {
        $insert_sql = "INSERT INTO categories (cat_title) VALUES ('$new_cat_title')";
        if ($conn->query($insert_sql) === TRUE) {
            echo "<script>alert('Category added successfully');</script>";
        } else {
            echo "<script>alert('Error adding category: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('Category title cannot be empty');</script>";
    }
}

// Handle brand addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_brand'])) {
    $new_brand_title = $_POST['brand_title'];
    if (!empty($new_brand_title)) {
        $insert_sql = "INSERT INTO brands (brand_title) VALUES ('$new_brand_title')";
        if ($conn->query($insert_sql) === TRUE) {
            echo "<script>alert('Brand added successfully');</script>";
        } else {
            echo "<script>alert('Error adding brand: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('Brand name cannot be empty');</script>";
    }
}

// Handle category deletion
if (isset($_GET['delete_category'])) {
    $delete_id = $_GET['delete_category'];
    $delete_sql = "DELETE FROM categories WHERE cat_id = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Category deleted successfully');</script>";
    } else {
        echo "<script>alert('Error deleting category: " . $conn->error . "');</script>";
    }
}

// Handle brand deletion
if (isset($_GET['delete_brand'])) {
    $delete_id = $_GET['delete_brand'];
    $delete_sql = "DELETE FROM brands WHERE brand_id = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Brand deleted successfully');</script>";
    } else {
        echo "<script>alert('Error deleting brand: " . $conn->error . "');</script>";
    }
}

// Fetch categories and brands
$categories = $conn->query("SELECT * FROM categories");
$brands = $conn->query("SELECT * FROM brands");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories & Brands</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
        }
        .nav-tabs .nav-link.active {
            background-color: #007bff;
            color: #fff;
        }
        h1 {
            margin-top: 20px;
        }
        .table th {
            background-color: #007bff;
            color: #fff;
        }
        .container {
            margin-top: 30px;
            max-width: 1000px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Manage Categories & Brands</h1>
        <!-- Tabs Navigation -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="categories-tab" data-bs-toggle="tab" data-bs-target="#categories" type="button" role="tab" aria-controls="categories" aria-selected="true">Categories</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="brands-tab" data-bs-toggle="tab" data-bs-target="#brands" type="button" role="tab" aria-controls="brands" aria-selected="false">Brands</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <!-- Categories Section -->
            <div class="tab-pane fade show active" id="categories" role="tabpanel" aria-labelledby="categories-tab">
                <form method="POST" class="my-4">
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" name="cat_title" class="form-control" placeholder="Enter Category Title" required>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" name="add_category" class="btn btn-primary">Add Category</button>
                        </div>
                    </div>
                </form>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Category ID</th>
                            <th>Category Title</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($categories->num_rows > 0) {
                            while ($row = $categories->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['cat_id']}</td>
                                    <td>{$row['cat_title']}</td>
                                    <td>
                                        <a href='?delete_category={$row['cat_id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this category?\")'>Delete</a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' class='text-center'>No categories found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- Brands Section -->
            <div class="tab-pane fade" id="brands" role="tabpanel" aria-labelledby="brands-tab">
                <form method="POST" class="my-4">
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" name="brand_title" class="form-control" placeholder="Enter Brand Title" required>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" name="add_brand" class="btn btn-primary">Add Brand</button>
                        </div>
                    </div>
                </form>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Brand ID</th>
                            <th>Brand Title</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($brands->num_rows > 0) {
                            while ($row = $brands->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['brand_id']}</td>
                                    <td>{$row['brand_title']}</td>
                                    <td>
                                        <a href='?delete_brand={$row['brand_id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this brand?\")'>Delete</a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' class='text-center'>No brands found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
