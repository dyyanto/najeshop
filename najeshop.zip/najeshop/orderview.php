<?php
include 'dbconnect.php';

// Handle deletion if delete request is sent
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM customer_order WHERE id = $delete_id"; // Replace 'id' with your primary key column
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Order deleted successfully');</script>";
    } else {
        echo "<script>alert('Error deleting order: " . $conn->error . "');</script>";
    }
}

// Query to retrieve data from the customer_order table
$order_sql = "SELECT * FROM customer_order"; 
$order_result = $conn->query($order_sql);

// Query to retrieve data from the user_info table
$user_sql = "SELECT * FROM user_info"; 
$user_result = $conn->query($user_sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
        }

        .container {
            max-width: 1200px;
            margin-top: 40px;
        }

        h1 {
            margin: 20px 0;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        .table td {
            vertical-align: middle;
        }

        .nav-tabs .nav-link.active {
            background-color: #007bff;
            color: white;
        }

        .nav-link {
            font-weight: bold;
        }

        .table-dark {
            background-color: #343a40;
            color: white;
        }

        .btn {
            transition: background-color 0.3s ease;
        }

        .btn-danger:hover {
            background-color: #d9534f;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-success:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 class="text-center">Admin Panel</h1>

        <!-- Tabs Navigation -->
        <ul class="nav nav-tabs" id="adminTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="orders-tab" data-bs-toggle="tab" data-bs-target="#orders" type="button" role="tab" aria-controls="orders" aria-selected="true">Customer Orders</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="users-tab" data-bs-toggle="tab" data-bs-target="#users" type="button" role="tab" aria-controls="users" aria-selected="false">User Info</button>
            </li>
        </ul>

        <!-- Tab Content -->
        <div class="tab-content mt-4" id="adminTabContent">
            <!-- Customer Orders Tab -->
            <div class="tab-pane fade show active" id="orders" role="tabpanel" aria-labelledby="orders-tab">
                <h2 class="text-center">Customer Orders</h2>
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>User ID</th>
                            <th>Product ID</th>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($order_result->num_rows > 0) {
                            while ($row = $order_result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['uid']}</td>
                                    <td>{$row['pid']}</td>
                                    <td>{$row['p_name']}</td>
                                    <td>{$row['p_price']}</td>
                                    <td>{$row['p_qty']}</td>
                                    <td>{$row['p_status']}</td>
                                    <td>
                                        <a href='?delete_id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this order?\")'>Delete</a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center'>No orders found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- User Info Tab -->
            <div class="tab-pane fade" id="users" role="tabpanel" aria-labelledby="users-tab">
                <h2 class="text-center">User Info</h2>
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>User ID</th>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($user_result->num_rows > 0) {
                            while ($row = $user_result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['user_id']}</td>
                                    <td>{$row['first_name']} {$row['last_name']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['mobile']}</td>
                                    <td>{$row['address1']} {$row['address2']}</td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>No user info found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JavaScript for interactivity -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
