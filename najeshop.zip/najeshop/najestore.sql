-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2024 at 05:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `najestore`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'NAJE AIR BRUSH');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_image` varchar(300) NOT NULL,
  `qty` int(100) NOT NULL,
  `price` int(100) NOT NULL,
  `total_amount` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'EX5'),
(2, 'Y16 / Y15'),
(3, 'LCV8');

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `p_price` int(100) NOT NULL,
  `p_qty` int(100) NOT NULL,
  `p_status` varchar(100) NOT NULL,
  `tr_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`id`, `uid`, `pid`, `p_name`, `p_price`, `p_qty`, `p_status`, `tr_id`) VALUES
(33, 7, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '1037516885'),
(34, 7, 2, 'Ex5 Ghost Rider [[READY STOCK]]', 200, 1, 'CONFIRMED', '1037516885'),
(35, 7, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '579638522'),
(36, 7, 6, 'Y16 - LC VxJ [[READY STOCK]]', 300, 1, 'CONFIRMED', '1220373832'),
(37, 7, 9, 'Y15ZR V2 /Y16ZR PALESTINE [[READY STOCK]]', 300, 1, 'CONFIRMED', '1220373832'),
(38, 7, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '1404713973'),
(39, 7, 4, 'Lc v8 [[READY STOCK]]', 250, 1, 'CONFIRMED', '1404713973'),
(40, 7, 5, 'Lc v8 Joker[[READY STOCK]]', 250, 1, 'CONFIRMED', '1404713973'),
(41, 7, 4, 'Lc v8 [[READY STOCK]]', 250, 1, 'CONFIRMED', '1024047655'),
(42, 7, 5, 'Lc v8 Joker[[READY STOCK]]', 250, 1, 'CONFIRMED', '1024047655'),
(43, 7, 4, 'Lc v8 [[READY STOCK]]', 250, 1, 'CONFIRMED', '1582421612'),
(44, 7, 2, 'Ex5 Ghost Rider [[READY STOCK]]', 200, 1, 'CONFIRMED', '1582421612'),
(45, 7, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '1557122811'),
(46, 7, 2, 'Ex5 Ghost Rider [[READY STOCK]]', 200, 1, 'CONFIRMED', '1557122811'),
(47, 7, 3, 'Ex5 Malaysia [[READY STOCK]] ', 200, 1, 'CONFIRMED', '1557122811'),
(48, 7, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '2096808736'),
(49, 8, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '167013887'),
(50, 8, 3, 'Ex5 Malaysia [[READY STOCK]] ', 200, 1, 'CONFIRMED', '167013887'),
(51, 8, 2, 'Ex5 Ghost Rider [[READY STOCK]]', 200, 1, 'CONFIRMED', '167013887'),
(52, 8, 4, 'Lc v8 [[READY STOCK]]', 250, 1, 'CONFIRMED', '167013887'),
(53, 8, 6, 'Y16 - LC VxJ [[READY STOCK]]', 300, 1, 'CONFIRMED', '18811570'),
(54, 8, 8, 'Y15 V2 / Y 16 OP [[READY STOCK]]', 350, 1, 'CONFIRMED', '18811570'),
(55, 8, 9, 'Y15ZR V2 /Y16ZR PALESTINE [[READY STOCK]]', 300, 1, 'CONFIRMED', '18811570'),
(56, 8, 11, 'Dada Ex5 Malaysia Carbon [[READY STOCK]]', 80, 1, 'CONFIRMED', '18811570'),
(57, 8, 2, 'Ex5 Ghost Rider [[READY STOCK]]', 200, 1, 'CONFIRMED', '1281371267'),
(58, 8, 5, 'Lc v8 Joker[[READY STOCK]]', 250, 1, 'CONFIRMED', '892700762'),
(59, 8, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '900874966'),
(60, 8, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '835941536'),
(61, 8, 3, 'Ex5 Malaysia [[READY STOCK]] ', 200, 1, 'CONFIRMED', '835941536'),
(62, 8, 1, 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 1, 'CONFIRMED', '2001930243'),
(63, 8, 2, 'Ex5 Ghost Rider [[READY STOCK]]', 200, 1, 'CONFIRMED', '2001930243'),
(64, 8, 3, 'Ex5 Malaysia [[READY STOCK]] ', 200, 1, 'CONFIRMED', '2001930243'),
(65, 8, 6, 'Y16 - LC VxJ [[READY STOCK]]', 300, 1, 'CONFIRMED', '2001930243');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` varchar(100) NOT NULL,
  `product_brand` varchar(100) NOT NULL,
  `product_title` varchar(50) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, '1', '1', 'Ex5 Doraemon Zombie [[READY STOCK]]', 200, 'Ex5 Doraemon Zombie - AIR BRUSH', 'ex5dz.JPG', 'ex5 mud guard motor'),
(2, '1', '1', 'Ex5 Ghost Rider [[READY STOCK]]', 200, 'Ex5 Ghost Rider - AIR BRUSH', 'ex5gr.JPG', 'ex5 mud guard motor'),
(3, '1', '1', 'Ex5 Malaysia [[READY STOCK]] ', 200, 'Ex5 Malaysia Johor Carbon Effect - AIR BRUSH', 'ex5m.jpg', 'ex5 mud guard motor'),
(4, '3', '1', 'Lc v8 [[READY STOCK]]', 250, 'Lc v8 Malaysia VS Penang - AIR BRUSH', 'lcv8m.JPG', 'lcv8 mud guard motor'),
(5, '3', '1', 'Lc v8 Joker[[READY STOCK]]', 250, 'Lc V8 Joker (Why So Serious) - AIR BRUSH', 'lcv8j.JPG', 'lcv8 mud guard motor joker'),
(6, '2', '1', 'Y16 - LC VxJ [[READY STOCK]]', 300, 'LC 135 V1 - V8 & Y 15 V1, V2 DAN Y 16 VENOM X JOKER-AIR BRUSH', 'y16jv.JPG', 'lcv8 y16 mud guard motor venom x joker'),
(7, '3', '1', 'Y16 - LC VxJ [[READY STOCK]]', 300, 'LC 135 V1 - V8 & Y 15 V1, V2 DAN Y 16 VENOM X JOKER-AIR BRUSH', 'y16jv.JPG', 'lcv8 y16 mud guard motor venom x joker'),
(8, '2', '1', 'Y15 V2 / Y 16 OP [[READY STOCK]]', 350, 'Y15 V2 / Y 16 ONE PIECE - AIR BRUSH', 'y16op.JPG', 'y15 y16 mud guard one piece'),
(9, '2', '1', 'Y15ZR V2 /Y16ZR PALESTINE [[READY STOCK]]', 300, 'Y15ZR V2 /Y16ZR PALESTINE- AIR BRUSH - MUD GUARD', 'y16pales.JPG', 'y15 y16 mud guard palestine'),
(10, '1', '1', 'dada Ex5 One Piece [[READY STOCK]]', 70, 'dada Ex5 One Piece - AIR BRUSH - MUD GUARD', 'dadaex5op.JPG', 'ex5 dada onepice'),
(11, '1', '1', 'Dada Ex5 Malaysia Carbon [[READY STOCK]]', 80, 'Dada Ex5 Malaysia Carbon - AIR BRUSH - MUD GUARD', 'dadaex5car.JPG', 'ex5 dada carbon'),
(12, '1', '1', 'Dada Ex5 Candy Design [[READY STOCK]]', 80, 'Dada Ex5 Candy Design - MUD GUARD - AIR BRUSH', 'dadaex5candy.JPG', 'ex5 dada mud guard candy design'),
(13, '1', '1', 'Cover Fork Ex5 Kedah [[READY STOCK]]', 121, 'Cover Fork Ex5 Kedah - AIR BRUSH - COVER FORK', 'ex5cfk.JPG', 'ex5 coverfork kedah'),
(14, '1', '1', 'Cover Fork Ex5 Johor Carbon [[READY STOCK]]', 124, 'Cover Fork Ex5 Johor Carbon - AIR BRUSH - COVER FOX', 'ex5cfj.JPG', 'ex5 coverfork johor'),
(16, '1', '1', 'Cover Fork Ex5 Malaysia [[READY STOCK]]', 164, 'Cover Fork Ex5 Malaysia - AIR BRUSH - COVER FORK', 'ex5cfm.JPG', 'ex5 coverfork malaysia ');

-- --------------------------------------------------------

--
-- Table structure for table `received_payment`
--

CREATE TABLE `received_payment` (
  `id` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `amt` int(100) NOT NULL,
  `tr_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(6, 'Dr', 'Red', 'adifahmishafie@gmail.com', '6c96e19140c279962eaddb188409ac67', '9245247532', 'fwwfwf', 'ffefe'),
(7, 'Dy ', 'Dafgag', 'sofeaakmal86@gmail.com', '6c96e19140c279962eaddb188409ac67', '2352534654', 'faeafef', 'egsegeg'),
(8, 'Dagty', 'Gren', 'adipak@gmail.com', '6c96e19140c279962eaddb188409ac67', '0145245353', 'RGRHRH', 'RTHRHR');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `received_payment`
--
ALTER TABLE `received_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `received_payment`
--
ALTER TABLE `received_payment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
