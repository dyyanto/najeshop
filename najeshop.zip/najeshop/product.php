<?php
include 'dbconnect.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $product_cat = $_POST['product_cat'];
    $product_brand = $_POST['product_brand'];
    $product_title = $_POST['product_title'];
    $product_price = $_POST['product_price'];
    $product_desc = $_POST['product_desc'];
    $product_image = $_POST['product_image'];
    $product_keywords = $_POST['product_keywords'];

    $insert_sql = "INSERT INTO products (product_cat, product_brand, product_title, product_price, product_desc, product_image, product_keywords) 
                   VALUES ('$product_cat', '$product_brand', '$product_title', '$product_price', '$product_desc', '$product_image', '$product_keywords')";

    if ($conn->query($insert_sql) === TRUE) {
        echo "<script>alert('New product added successfully');</script>";
    } else {
        echo "<script>alert('Error adding product: " . $conn->error . "');</script>";
    }
}


if (isset($_GET['delete_product_id'])) {
    $product_id = $_GET['delete_product_id'];
    
   
    $delete_sql = "DELETE FROM products WHERE product_id = $product_id";
    
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Product deleted successfully');</script>";
        header('Location:product.php'); 
        exit;
    } else {
        echo "<script>alert('Error deleting product: " . $conn->error . "');</script>";
    }
}


$categories = $conn->query("SELECT * FROM categories");
$brands = $conn->query("SELECT * FROM brands");
$products = $conn->query("SELECT * FROM products");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
        }
        .nav-tabs .nav-link.active {
            background-color: #007bff;
            color: #fff;
        }
        h1 {
            margin-top: 20px;
        }
        .table th {
            background-color: #007bff;
            color: #fff;
        }
        .container {
            margin-top: 30px;
            max-width: 1200px;
        }
        .form-label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Manage Products</h1>

      
        <div class="mb-4">
            <h2>Add New Product</h2>
            <form method="POST" class="row g-3">
                <div class="col-md-6">
                    <label for="product_cat" class="form-label">Product Category</label>
                    <select name="product_cat" id="product_cat" class="form-select" required>
                        <option value="" disabled selected>Select Category</option>
                        <?php while ($cat = $categories->fetch_assoc()) {
                            echo "<option value='{$cat['cat_id']}'>{$cat['cat_title']}</option>";
                        } ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="product_brand" class="form-label">Product Brand</label>
                    <select name="product_brand" id="product_brand" class="form-select" required>
                        <option value="" disabled selected>Select Brand</option>
                        <?php while ($brand = $brands->fetch_assoc()) {
                            echo "<option value='{$brand['brand_id']}'>{$brand['brand_title']}</option>";
                        } ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="product_title" class="form-label">Product Title</label>
                    <input type="text" name="product_title" id="product_title" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="product_price" class="form-label">Product Price [RM]</label>
                    <input type="number" name="product_price" id="product_price" class="form-control" required>
                </div>
                <div class="col-md-12">
                    <label for="product_desc" class="form-label">Product Description</label>
                    <textarea name="product_desc" id="product_desc" class="form-control" rows="3" required></textarea>
                </div>
                <div class="col-md-6">
                    <label for="product_image" class="form-label">Product Image (Filename must be image.JPG)</label>
                    <input type="text" name="product_image" id="product_image" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="product_keywords" class="form-label">Product Keywords</label>
                    <input type="text" name="product_keywords" id="product_keywords" class="form-control" required>
                </div>
                <div class="col-md-12">
                    <button type="submit" name="add_product" class="btn btn-primary">Add Product</button>
                </div>
            </form>
        </div>

        
        <h2>Product List</h2>
        <div class="table-responsive mb-4">
            <table class="table table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Keywords</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($products->num_rows > 0) {
                        while ($product = $products->fetch_assoc()) {
                            echo "<tr>
                                <td>{$product['product_id']}</td>
                                <td>{$product['product_cat']}</td>
                                <td>{$product['product_brand']}</td>
                                <td>{$product['product_title']}</td>
                                <td>{$product['product_price']}</td>
                                <td>{$product['product_desc']}</td>
                                <td>{$product['product_image']}</td>
                                <td>{$product['product_keywords']}</td>
                                <td>
                                    <a href='?delete_product_id={$product['product_id']}' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this product?\");'>Delete</a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='9' class='text-center'>No products found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="categories-tab" data-bs-toggle="tab" data-bs-target="#categories" type="button" role="tab">Categories</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="brands-tab" data-bs-toggle="tab" data-bs-target="#brands" type="button" role="tab">Brands</button>
            </li>
        </ul>
        <div class="tab-content mt-4">
            <div class="tab-pane fade show active" id="categories" role="tabpanel">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $categories->data_seek(0);
                        while ($cat = $categories->fetch_assoc()) {
                            echo "<tr><td>{$cat['cat_id']}</td><td>{$cat['cat_title']}</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade" id="brands" role="tabpanel">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $brands->data_seek(0);
                        while ($brand = $brands->fetch_assoc()) {
                            echo "<tr><td>{$brand['brand_id']}</td><td>{$brand['brand_title']}</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
